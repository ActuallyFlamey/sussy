"""when the python developer is sus"""

from characters import *