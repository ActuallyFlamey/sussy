from distutils.core import setup

setup(
    name = "sussy",
    packages = ["sussy"],
    version = "0.1.0",
    description = "when the python developer is sus",
    author = "Flamey",
    url = "https://github.com/ActuallyFlamey/sussy/",
    download_url = "https://github.com/ActuallyFlamey/sussy/archive/refs/tags/0.1.0.tar.gz"
)